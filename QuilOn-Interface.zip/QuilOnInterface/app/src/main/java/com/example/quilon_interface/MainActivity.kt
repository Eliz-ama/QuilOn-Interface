package com.example.quilon_interface

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory




class EdicaoProdutoActivity : AppCompatActivity() {

    private var imageViewIndex = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.edicao_produto)

//  <<<<<<<<<<<<<<<<<<   Titulo  >>>>>>>>>>>>>>>>>>
        val txtTitulo1: EditText = findViewById(R.id.txt_titulo1)

        // Criar uma variável com o valor "teste"
        val valorTitulo = "Cesto"

        // Preencher o EditText com o valor da variável
        txtTitulo1.setText(valorTitulo)

//  <<<<<<<<<<<<<<<<<<   Categoria  >>>>>>>>>>>>>>>>>>
        // Primeiro Spinner
        val spinnerTipo = findViewById<Spinner>(R.id.spinnerTipo)
        val adapterTipo = ArrayAdapter.createFromResource(
            this,
            R.array.tipos,
            R.layout.spinner_item_layout
        )
        adapterTipo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTipo.adapter = adapterTipo

        // Define o valor padrão no primeiro Spinner
        val valorPadraoTipo = "Artesanato"
        val posicaoPadraoTipo = adapterTipo.getPosition(valorPadraoTipo)
        spinnerTipo.setSelection(posicaoPadraoTipo)

//  <<<<<<<<<<<<<<<<<<   Descrição  >>>>>>>>>>>>>>>>>>
        val txt_descricao: EditText = findViewById(R.id.txt_descricao)

        // Criar uma variável com o valor "teste"
        val valorDescricao = "Trama de criatividade, cores e texturas, obra de arte em cada ponto."

        // Preencher o EditText com o valor da variável
        txt_descricao.setText(valorDescricao)

//  <<<<<<<<<<<<<<<<<<   Prazo  >>>>>>>>>>>>>>>>>>
        // Segundo Spinner
        val spinnerPrazo = findViewById<Spinner>(R.id.spinnerPrazo)
        val adapterPrazo = ArrayAdapter.createFromResource(
            this,
            R.array.prazo,
            R.layout.spinner_item_layout
        )
        adapterPrazo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPrazo.adapter = adapterPrazo

        // Define o valor padrão no segundo Spinner
        val valorPadraoPrazo = "De 1 a 5 dias"
        val posicaoPadraoPrazo = adapterPrazo.getPosition(valorPadraoPrazo)
        spinnerPrazo.setSelection(posicaoPadraoPrazo)

//  <<<<<<<<<<<<<<<<<<   Botão Adicionar Foto  >>>>>>>>>>>>>>>>>>
        val adicionarFotoButton = findViewById<ImageButton>(R.id.adicionar_foto)
        adicionarFotoButton.setOnClickListener { openImagePicker() }

//  <<<<<<<<<<<<<<<<<<   Imagem 1  >>>>>>>>>>>>>>>>>>
        val imageView1: ImageView = findViewById(R.id.imagem1)
        imageView1.setImageResource(R.drawable.image_artesanato)

//  <<<<<<<<<<<<<<<<<<   Imagem 2  >>>>>>>>>>>>>>>>>>
        val imageView2: ImageView = findViewById(R.id.imagem2)
        imageView2.setImageResource(R.drawable.image_artesanato)

//  <<<<<<<<<<<<<<<<<<   Imagem 3  >>>>>>>>>>>>>>>>>>
        val imageView3: ImageView = findViewById(R.id.imagem3)
        imageView3.setImageResource(R.drawable.image_artesanato)

//  <<<<<<<<<<<<<<<<<<   Preço  >>>>>>>>>>>>>>>>>>
        val txt_preco: EditText = findViewById(R.id.txt_preco)

        // Criar uma variável com o valor "teste"
        val valorPreco = "R$ 22,50"

        // Preencher o EditText com o valor da variável
        txt_preco.setText(valorPreco)


//  <<<<<<<<<<<<<<<<<<   Estoque  >>>>>>>>>>>>>>>>>>
        val txt_estoque: EditText = findViewById(R.id.txt_estoque)

        // Criar uma variável com o valor "teste"
        val valorEstoque = "12 Unidades"

        // Preencher o EditText com o valor da variável
        txt_estoque.setText(valorEstoque)

//  <<<<<<<<<<<<<<<<<<   Botão Salvar  >>>>>>>>>>>>>>>>>>
        val btnSalvar: ImageButton = findViewById(R.id.btn_salvar)

        btnSalvar.setOnClickListener {
            val exibeProdutoIntent = Intent(this, ExibicaoProdutoActivity::class.java)
            startActivity(exibeProdutoIntent)
        }

//  <<<<<<<<<<<<<<<<<<   Botão Deletar Produto  >>>>>>>>>>>>>>>>>>


    }
//  <<<<<<<<<<<<<<<<<<   Funções para Adicionar Foto  >>>>>>>>>>>>>>>>>>
    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_IMAGE_PICK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK) {
            if (data != null) {
                val selectedImageUri = data.data
                if (selectedImageUri != null) {
                    try {
                        val bitmap = MediaStore.Images.Media.getBitmap(
                            this.contentResolver,
                            selectedImageUri
                        )
                        val imageView: ImageView? = getNextImageView()
                        imageView?.setImageBitmap(bitmap)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

//  <<<<<<<<<<<<<<<<<<   Função para Adicionar Foto na sequência >>>>>>>>>>>>>>>>>>
    private fun getNextImageView(): ImageView? {
    return when (imageViewIndex) {
        1 -> {
            imageViewIndex++
            findViewById(R.id.imagem1)
        }

        2 -> {
            imageViewIndex++
            findViewById(R.id.imagem2)
        }

        3 -> {
            imageViewIndex = 1 // Volta para a primeira ImageView se atingir a terceira
            findViewById(R.id.imagem3)
        }

        else -> null
    }
    }

    companion object {
        private const val REQUEST_IMAGE_PICK = 1
    }
}


class ExibicaoProdutoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.exibicao_produto)

//  <<<<<<<<<<<<<<<<<<   Categoria  >>>>>>>>>>>>>>>>>>
        val spinnerTipo = findViewById<Spinner>(R.id.spinnerTipo)
        val adapterTipo = ArrayAdapter.createFromResource(
            this,
            R.array.tipos,
            R.layout.spinner_item_layout
        )
        adapterTipo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTipo.adapter = adapterTipo
    }

//  <<<<<<<<<<<<<<<<<<   Acessar Produto  >>>>>>>>>>>>>>>>>>
    fun abrirInterfaceEdicaoProduto() {
        val editeProdutoIntent = Intent(this, EdicaoProdutoActivity::class.java)
        startActivity(editeProdutoIntent)
    }

}


class MainActivity : AppCompatActivity() {

    private val apiService = Conexao().createApiService()

    private lateinit var txtTitulo: EditText
   // private lateinit var spinnerTipo: Spinner
    private lateinit var txtDescricao: EditText
    private lateinit var txtPreco: EditText
    private lateinit var txtEstoque: EditText
   // private lateinit var btnConfirmar: ImageButton


    private var imageViewIndex = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cadastro_produto)

//  <<<<<<<<<<<<<<<<<<   Categoria  >>>>>>>>>>>>>>>>>>
        // Recupera o `Spinner` Tipo
        val spinnerTipo = findViewById<Spinner>(R.id.spinnerTipo)
        val adapterTipo = ArrayAdapter.createFromResource(
            this,
            R.array.tipos,
            R.layout.spinner_item_layout
        )
        adapterTipo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTipo.adapter = adapterTipo

        // Recupera o `Spinner` Prazo
        val spinnerPrazo = findViewById<Spinner>(R.id.spinnerPrazo)
        val adapterPrazo = ArrayAdapter.createFromResource(
            this,
            R.array.prazo,
            R.layout.spinner_item_layout
        )
        adapterPrazo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerPrazo.adapter = adapterPrazo


//  <<<<<<<<<<<<<<<<<<   Botão Adicionar Foto  >>>>>>>>>>>>>>>>>>
        val adicionarFotoButton = findViewById<ImageButton>(R.id.adicionar_foto)
        adicionarFotoButton.setOnClickListener { openImagePicker() }

//  <<<<<<<<<<<<<<<<<<   Botão Confirmar  >>>>>>>>>>>>>>>>>>

        val btnConfirmar: ImageButton = findViewById(R.id.btn_confirmar)

        this.txtTitulo = findViewById(R.id.txt_titulo1)
        this.txtDescricao = findViewById(R.id.txt_descricao)
        this.txtPreco = findViewById(R.id.txt_preco)
        this.txtEstoque = findViewById(R.id.txt_estoque)

        btnConfirmar.setOnClickListener {




            val produto = Produto(
                title = txtTitulo.text.toString(),
                category = spinnerTipo.selectedItem.toString(),
                description = txtDescricao.text.toString(),
                production_time = spinnerPrazo.selectedItem.toString(),
                price = txtPreco.text.toString(),
                stock = txtEstoque.text.toString()
            ).also {

                //Log.i("TESSETETE", it.toString())
                // Enviar dados para a API
                enviarDadosParaApi(it)
            }



        }

//  <<<<<<<<<<<<<<<<<<   Preparar dados para o banco  >>>>>>>>>>>>>>>>>>
//        btnConfirmar.setOnClickListener {
//            // Aqui você pode obter os valores e enviar para a API
//            val produto = Produto(
//                title = txtTitulo.text.toString(),
//                category = spinnerTipo.selectedItem.toString(),
//                description = txtDescricao.text.toString(),
//                production_time = spinnerPrazo.selectedItem.toString(),
//                price = txtPreco.text.toString(),
//                stock = txtEstoque.text.toString()
//            )
//
//            // Enviar dados para a API
//            enviarDadosParaApi(produto)
//        }
    }
//  <<<<<<<<<<<<<<<<<<   Funções para Enviar os Dados  >>>>>>>>>>>>>>>>>>
    private fun enviarDadosParaApi(produto: Produto) {
        val ApiService = Conexao().createApiService()
        Log.i("aaaaaa","aaaaaaaaaaaaaaaaaaaaaaaaaaa--------------")
        Log.i("api", ApiService.toString())

        val call = ApiService.enviarDados(produto)
        Log.i("api", call.toString())


        call.enqueue(object : Callback<ResponseBody> {
            override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {

                if (response.isSuccessful == true) {
                  Log.i("server-response",response.raw().toString())
                    Log.i("server-response",response.message())
                    // Dados enviados com sucesso
                    Toast.makeText(applicationContext, "Dados enviados com sucesso", Toast.LENGTH_SHORT).show()
                } else {

                    // Tratar erro de resposta não bem-sucedida
                    Toast.makeText(applicationContext, "Erro ao enviar dados", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                // Tratar falha na requisição
                Log.i("bb", t.message.toString())
                Toast.makeText(applicationContext, t.message, Toast.LENGTH_SHORT).show()
            }
        })
    }



//  <<<<<<<<<<<<<<<<<<   Funções para Adicionar Foto  >>>>>>>>>>>>>>>>>>
    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_IMAGE_PICK)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK) {
            if (data != null) {
                val selectedImageUri = data.data
                if (selectedImageUri != null) {
                    try {
                        val bitmap = MediaStore.Images.Media.getBitmap(
                            this.contentResolver,
                            selectedImageUri
                        )
                        val imageView: ImageView? = getNextImageView()
                        imageView?.setImageBitmap(bitmap)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

//  <<<<<<<<<<<<<<<<<<   Função para Adicionar Foto na sequência >>>>>>>>>>>>>>>>>>
    @SuppressLint("WrongViewCast")
    private fun getNextImageView(): ImageView? {

    return when (imageViewIndex) {
        1 -> {
            imageViewIndex++
            findViewById(R.id.imagem1)
        }

        2 -> {
            imageViewIndex++
            findViewById(R.id.imagem2)
        }

        3 -> {
            imageViewIndex = 1 // Volta para a primeira ImageView se atingir a terceira
            findViewById(R.id.imagem3)
        }

        else -> null
    }
    }

    companion object {
        private const val REQUEST_IMAGE_PICK = 1
    }
}







