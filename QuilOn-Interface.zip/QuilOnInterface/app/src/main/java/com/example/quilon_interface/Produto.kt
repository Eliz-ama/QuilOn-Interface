package com.example.quilon_interface
data class Produto(
    val title: String,
    val category: String,
    val description: String,
    val production_time: String,
    val price: String,
    val stock: String
)
